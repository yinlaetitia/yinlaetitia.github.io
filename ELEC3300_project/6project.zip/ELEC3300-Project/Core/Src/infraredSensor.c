#include "infraredSensor.h"

int humanMotion = 0;
int lastHumanMotion = -HUMAN_LEAVE_TIME;

void infraredSensorInit(void){
    registerUpdateFunc(infraredSensorUpdate);
}

void infraredSensorUpdate(void){
    humanMotion = HAL_GPIO_ReadPin(INFRARED_SENSOR_PORT, INFRARED_SENSOR_PIN);
    if (humanMotion) {
        lastHumanMotion = HAL_GetTick();
    }
}

int hasHuman(void){
    if (HAL_GetTick() - lastHumanMotion < HUMAN_LEAVE_TIME) {
        return 1;
    }
    return 0;
}