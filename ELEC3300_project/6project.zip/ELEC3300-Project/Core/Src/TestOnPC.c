
// #include "../Inc/testJSON.h"
#include "../Inc/jsonUtils.h"

const char *testStr = "{\"rainfall\":{\"data\":[{\"unit\":\"mm\",\"place\":\"Central & Western District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Eastern District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Kwai Tsing\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Islands District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"North District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Sai Kung\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Sha Tin\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Southern District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Tai Po\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Tsuen Wan\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Tuen Mun\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Wan Chai\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Yuen Long\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Yau Tsim Mong\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Sham Shui Po\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Kowloon City\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Wong Tai Sin\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Kwun Tong\",\"max\":0,\"main\":\"FALSE\"}],\"startTime\":\"2023-05-07T08:45:00+08:00\",\"endTime\":\"2023-05-07T09:45:00+08:00\"},\"icon\":[62],\"iconUpdateTime\":\"2023-05-07T08:10:00+08:00\",\"uvindex\":{\"data\":[{\"place\":\"King\'s Park\",\"value\":1,\"desc\":\"low\"}],\"recordDesc\":\"During the past hour\"},\"updateTime\":\"2023-05-07T10:02:00+08:00\",\"temperature\":{\"data\":[{\"place\":\"King\'s Park\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Hong Kong Observatory\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Wong Chuk Hang\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Ta Kwu Ling\",\"value\":31,\"unit\":\"C\"},{\"place\":\"Lau Fau Shan\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Tai Po\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Sha Tin\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Tuen Mun\",\"value\":28,\"unit\":\"C\"},{\"place\":\"Tseung Kwan O\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Sai Kung\",\"value\":28,\"unit\":\"C\"},{\"place\":\"Cheung Chau\",\"value\":31,\"unit\":\"C\"},{\"place\":\"Chek Lap Kok\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Shek Kong\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Tsuen Wan Ho Koon\",\"value\":27,\"unit\":\"C\"},{\"place\":\"Tsuen Wan Shing Mun Valley\",\"value\":27,\"unit\":\"C\"},{\"place\":\"Hong Kong Park\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Shau Kei Wan\",\"value\":28,\"unit\":\"C\"},{\"place\":\"Kowloon City\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Happy Valley\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Wong Tai Sin\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Stanley\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Kwun Tong\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Sham Shui Po\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Kai Tak Runway Park\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Yuen Long Park\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Tai Mei Tuk\",\"value\":28,\"unit\":\"C\"}],\"recordTime\":\"2023-05-07T10:00:00+08:00\"},\"warningMessage\":\"\",\"mintempFrom00To09\":\"\",\"rainfallFrom00To12\":\"\",\"rainfallLastMonth\":\"\",\"rainfallJanuaryToLastMonth\":\"\",\"tcmessage\":\"\",\"humidity\":{\"recordTime\":\"2023-05-07T10:00:00+08:00\",\"data\":[{\"unit\":\"percent\",\"value\":81,\"place\":\"Hong Kong Observatory\"}]}}";

char *testStr2 = "{\"generalSituation\":\"A trough of low pressure will bring unsettled weather to the coast of southern China at first tomorrow. With the trough of low pressure departing, showers will ease off gradually during the day tomorrow. Under the influence of the associated easterly airstream, it will be windier over the coast of Guangdong in the next couple of days. The anticyclone aloft over the northern part of the South China Sea is expected to strengthen midweek this week. The weather will improve slightly over the coastal areas.\",\"weatherForecast\":[{\"forecastDate\":\"20230508\",\"week\":\"Monday\",\"forecastWind\":\"North force 2 to 3, east force 5 later, occasionally force 6 offshore.\",\"forecastWeather\":\"Mainly cloudy with showers. Showers will be more frequent with thunderstorms at first. Showers will ease off during the day.\",\"forecastMaxtemp\":{\"value\":26,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":22,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":95,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":80,\"unit\":\"percent\"},\"ForecastIcon\":63,\"PSR\":\"High\"},{\"forecastDate\":\"20230509\",\"week\":\"Tuesday\",\"forecastWind\":\"East force 4 to 5, occasionally force 6 offshore.\",\"forecastWeather\":\"Mainly cloudy. Bright periods during the day.\",\"forecastMaxtemp\":{\"value\":25,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":22,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":85,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":75,\"unit\":\"percent\"},\"ForecastIcon\":60,\"PSR\":\"Low\"},{\"forecastDate\":\"20230510\",\"week\":\"Wednesday\",\"forecastWind\":\"East force 4 to 5, occasionally force 6 offshore at first.\",\"forecastWeather\":\"Mainly cloudy. Sunny intervals during the day.\",\"forecastMaxtemp\":{\"value\":26,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":23,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":85,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":65,\"unit\":\"percent\"},\"ForecastIcon\":52,\"PSR\":\"Low\"},{\"forecastDate\":\"20230511\",\"week\":\"Thursday\",\"forecastWind\":\"East force 4, force 5 at first.\",\"forecastWeather\":\"Sunny periods.\",\"forecastMaxtemp\":{\"value\":27,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":23,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":85,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":65,\"unit\":\"percent\"},\"ForecastIcon\":51,\"PSR\":\"Low\"},{\"forecastDate\":\"20230512\",\"week\":\"Friday\",\"forecastWind\":\"East force 3 to 4.\",\"forecastWeather\":\"Sunny intervals.\",\"forecastMaxtemp\":{\"value\":28,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":24,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":85,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":65,\"unit\":\"percent\"},\"ForecastIcon\":52,\"PSR\":\"Low\"},{\"forecastDate\":\"20230513\",\"week\":\"Saturday\",\"forecastWind\":\"East force 3 to 4.\",\"forecastWeather\":\"Mainly cloudy with a few showers.\",\"forecastMaxtemp\":{\"value\":27,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":24,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":95,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":75,\"unit\":\"percent\"},\"ForecastIcon\":62,\"PSR\":\"Medium Low\"},{\"forecastDate\":\"20230514\",\"week\":\"Sunday\",\"forecastWind\":\"Southeast force 3 to 4.\",\"forecastWeather\":\"Mainly cloudy with a few showers.\",\"forecastMaxtemp\":{\"value\":27,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":24,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":95,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":80,\"unit\":\"percent\"},\"ForecastIcon\":62,\"PSR\":\"Medium Low\"},{\"forecastDate\":\"20230515\",\"week\":\"Monday\",\"forecastWind\":\"Southeast force 3 to 4.\",\"forecastWeather\":\"Mainly cloudy with a few showers.\",\"forecastMaxtemp\":{\"value\":27,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":24,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":95,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":80,\"unit\":\"percent\"},\"ForecastIcon\":62,\"PSR\":\"Low\"},{\"forecastDate\":\"20230516\",\"week\":\"Tuesday\",\"forecastWind\":\"Southeast force 3 to 4.\",\"forecastWeather\":\"Mainly cloudy with a few showers.\",\"forecastMaxtemp\":{\"value\":27,\"unit\":\"C\"},\"forecastMintemp\":{\"value\":24,\"unit\":\"C\"},\"forecastMaxrh\":{\"value\":95,\"unit\":\"percent\"},\"forecastMinrh\":{\"value\":80,\"unit\":\"percent\"},\"ForecastIcon\":62,\"PSR\":\"Low\"}],\"updateTime\":\"2023-05-07T16:30:00+08:00\",\"seaTemp\":{\"place\":\"North Point\",\"value\":25,\"unit\":\"C\",\"recordTime\":\"2023-05-07T14:00:00+08:00\"},\"soilTemp\":[{\"place\":\"Hong Kong Observatory\",\"value\":26.6,\"unit\":\"C\",\"recordTime\":\"2023-05-07T07:00:00+08:00\",\"depth\":{\"unit\":\"metre\",\"value\":0.5}},{\"place\":\"Hong Kong Observatory\",\"value\":25.8,\"unit\":\"C\",\"recordTime\":\"2023-05-07T07:00:00+08:00\",\"depth\":{\"unit\":\"metre\",\"value\":1}}]}";
void printMystr(myStr_t *str)
{
    for (int i = 0; i < str->len; i++)
    {
        printf("%c", str->str[i]);
    }
    printf("\n");
}

int main()
{
    myStr_t str;
    str.str = testStr;
    str.len = strlen(testStr);
    rainfallData_t rainfallData[18];
    temperatureData_t temperatureData[25];
    weatherData_t weatherData;
    weatherData.rainfallData = rainfallData;
    weatherData.temperatureData = temperatureData;
    jsonParseCurrentWeatherData(&str, &weatherData);
    for (int i = 0; i < 18; i++)
    {
        printf("============================\n");
        printf("place:");
        printMystr(&rainfallData[i].place);
        printf("unit:");
        printMystr(&rainfallData[i].unit);
        printf("max:");
        printMystr(&rainfallData[i].max);
        printf("main:");
        printMystr(&rainfallData[i].main);
        
    }

    for (int i = 0; i < 25; i++)
    {
        printf("============================\n");
        printf("place:");
        printMystr(&temperatureData[i].place);
        printf("unit:");
        printMystr(&temperatureData[i].unit);
        printf("value:");
        printMystr(&temperatureData[i].value);
    }

    printf("============================\n");
    printMystr(&weatherData.updateTime);

    forecast_t forecast[11];
    forecastData_t forecastData;
    forecastData.weatherForecast = forecast;
    myStr_t testStr3;
    testStr3.str = testStr2;
    testStr3.len = strlen(testStr2);
    int code = jsonParseForecastData(&testStr3, &forecastData);
    printf("code: %d\n", code);
    for (int i = 0; i < 9; i++)
    {
        printf("============================\n");
        printMystr(&forecast[i].forecastDate);
        printMystr(&forecast[i].forecastMaxrh->unit);
        printMystr(&forecast[i].forecastMaxrh->value);
        printMystr(&forecast[i].forecastMaxtemp->unit);
        printMystr(&forecast[i].forecastMaxtemp->value);
        printMystr(&forecast[i].forecastMinrh->unit);
        printMystr(&forecast[i].forecastMinrh->value);
        printMystr(&forecast[i].forecastMintemp->unit);
        printMystr(&forecast[i].forecastMintemp->value);
        printMystr(&forecast[i].forecastWeather);
        printMystr(&forecast[i].forecastWind);
        printMystr(&forecast[i].PSR);
        printMystr(&forecast[i].week);
    }

    printf("============================\n");
    printMystr(&forecastData.generalSituation);
    // printMystr(&forecastData.updateTime);


    return 0;

}