#include "temperature.h"

float getTemperature()
{
    uint32_t val = 0;
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 100);
    val = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);
    return (val * 5.0 / 1024) * 10;
}

int command(int upperbound, int lowerbound, int tollerance, float temperature)
{
    if(temperature > (upperbound + tollerance))
    {
        return 1;
    }
    else if(temperature < (lowerbound - tollerance))
    {
        return 0;
    }
    else
    {
        return -1;
    }
    
}