#include "weather.h"

#include "update.h"
#include "wifi.h"
#include "state.h"

int timer = 0;


static char forecastStr[6000];
static char weatherStr[3096];

myStr_t volatile forecastMyStr = {forecastStr, 0};

myStr_t volatile weatherMyStr = {weatherStr, 0};

rainfallData_t volatile rainfallData[50];
temperatureData_t volatile temperatureData[50];
weatherData_t volatile weatherData = {temperatureData, 0, rainfallData, 0, {0, 0}};

forecast_t volatile forecast[FORECAST_SIZE];
valueUint_t volatile valueUints[FORECAST_SIZE * 4];
forecastData_t volatile forecastData = {{0}, forecast, 0, {0, 0}};

int updateWeatherDataFromStr()
{
    return jsonParseCurrentWeatherData(&weatherMyStr, &weatherData);
}

int updateForecastDataFromStr()
{
    return jsonParseForecastData(&forecastMyStr, &forecastData);
}

void updateWeatherStr(char *str)
{
    // get weather data str from server using uart
    // dummy now
    strcpy(weatherStr, str);
    weatherMyStr.len = strlen(str);
    updateWeatherDataFromStr();
    weatherUpdateCallback();
}
int forecastGetted = 0;

void updateForecastStr(char *str)
{
    // get forecast data str from server using uart
    strcpy(forecastStr, str);
    forecastGetted = 1;
    forecastMyStr.len = strlen(str);
    updateForecastDataFromStr();
}
int weatherLastTick = 0;
int weatherOrForecast = 0;

void weatherUpdate()
{
    if (timer <= 0)
    {
        if (forecastGetted == 0)
            addQuery(FORECAST, updateForecastStr);
        else
            addQuery(WEATHER, updateWeatherStr);
        // updateWeatherDataFromStr();
        // updateForecastStr(dummyForecast);
        // updateForecastDataFromStr();
        timer = WEATHER_UPDATE_INTERVAL;
    }
    if (weatherLastTick == 0)
    {
        weatherLastTick = HAL_GetTick();
    }
    else
    {
        int tick = HAL_GetTick();
        int delta = tick - weatherLastTick;
        weatherLastTick = tick;
        timer -= delta;
    }
}

void weatherInit()
{
    registerUpdateFunc(weatherUpdate);
    for (int i = 0; i < FORECAST_SIZE; i++)
    {
        forecast[i].forecastMaxtemp = valueUints + i * 4;
        forecast[i].forecastMintemp = valueUints + i * 4 + 1;
        forecast[i].forecastMaxrh = valueUints + i * 4 + 2;
        forecast[i].forecastMinrh = valueUints + i * 4 + 3;
    }
}

weatherData_t *getWeatherData(void)
{
    return &weatherData;
}

forecastData_t *getForecastData(void)
{
    return &forecastData;
}
