#include "jsonUtils.h"
#include "jsmn.h"

static char volatile jsonUtil[2048];
int jsoneq(char *json, jsmntok_t *tok, char *s)
{
    if (tok->type == JSMN_STRING && (int)strlen(s) == tok->end - tok->start &&
        strncmp(json + tok->start, s, tok->end - tok->start) == 0)
    {
        return 0;
    }
    return -1;
}

int jsonFindKey(char *json, jsmntok_t *tokens, int tokenSize, char *key)
{
    int i;
    for (i = 0; i < tokenSize; i++)
    {
        if (jsoneq(json, &tokens[i], key) == 0)
        {
            return i;
        }
    }
    return -1;
}

// returns size of value
int jsonGetVal(char *json, jsmntok_t *tokens, int tokenSize, char *key, char **val)
{
    int i;
    for (i = 0; i < tokenSize; i++)
    {
        if (jsoneq(json, &tokens[i], key) == 0)
        {
            // sprint debug
            sprintf(jsonUtil, "jsonGetVal: key: %s, val: %.*s\r\n", key, tokens[i + 1].end - tokens[i + 1].start, json + tokens[i + 1].start);
            *val = json + tokens[i + 1].start;
            return tokens[i + 1].end - tokens[i + 1].start;
        }
    }
    return -1;
}

int jsonParseRainfallData(myStr_t *json, rainfallData_t *data)
{
    jsmn_parser parser;
    jsmntok_t tokens[256]; // max 256 tokens
    int tokenSize;
    int i;

    jsmn_init(&parser);
    tokenSize = jsmn_parse(&parser, json->str, json->len, tokens, sizeof(tokens) / sizeof(tokens[0]));
    if (tokenSize < 0)
    {
        return -1;
    }

    // find unit
    findKeyAndLoadVal(json->str, tokens, tokenSize, "unit", &data->unit);
    // find place
    findKeyAndLoadVal(json->str, tokens, tokenSize, "place", &data->place);
    // find max
    findKeyAndLoadVal(json->str, tokens, tokenSize, "max", &data->max);
    // find min
    findKeyAndLoadVal(json->str, tokens, tokenSize, "min", &data->min);
    // find main
    findKeyAndLoadVal(json->str, tokens, tokenSize, "main", &data->main);

    return 0;
}

int jsonParseTemperatureData(myStr_t *json, temperatureData_t *data)
{
    jsmn_parser parser;
    jsmntok_t tokens[256];
    int tokenSize;
    int i;

    jsmn_init(&parser);
    tokenSize = jsmn_parse(&parser, json->str, json->len, tokens, sizeof(tokens) / sizeof(tokens[0]));
    if (tokenSize < 0)
    {
        return -1;
    }

    // find unit
    findKeyAndLoadVal(json->str, tokens, tokenSize, "unit", &data->unit);
    // find place
    findKeyAndLoadVal(json->str, tokens, tokenSize, "place", &data->place);
    // find value
    findKeyAndLoadVal(json->str, tokens, tokenSize, "value", &data->value);

    return 0;
}

int jsonParseValueUint(myStr_t *json, valueUint_t *data)
{
    jsmn_parser parser;
    jsmntok_t tokens[256];
    int tokenSize;
    int i;

    jsmn_init(&parser);
    tokenSize = jsmn_parse(&parser, json->str, json->len, tokens, sizeof(tokens) / sizeof(tokens[0]));
    if (tokenSize < 0)
    {
        return -1;
    }

    // find unit
    findKeyAndLoadVal(json->str, tokens, tokenSize, "unit", &data->unit);
    // find value
    findKeyAndLoadVal(json->str, tokens, tokenSize, "value", &data->value);

    return 0;
}

static valueUint_t volatile *valueUint;

int jsonParseForecast(myStr_t *json, forecast_t * const data)
{
    jsmn_parser parser;
    jsmntok_t tokens[256];
    int tokenSize;
    int i;

    jsmn_init(&parser);
    tokenSize = jsmn_parse(&parser, json->str, json->len, tokens, sizeof(tokens) / sizeof(tokens[0]));
    if (tokenSize < 0)
    {
        return -1;
    }

    // find forecastDate
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastDate", &data->forecastDate);
    // find week
    findKeyAndLoadVal(json->str, tokens, tokenSize, "week", &data->week);
    // find forecastWind
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastWind", &data->forecastWind);
    // find forecastWeather
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastWeather", &data->forecastWeather);
    myStr_t temp;
    // find forecastMaxtemp
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastMaxtemp", &temp);
    jsonParseValueUint(&temp, data->forecastMaxtemp);
    // find forecastMintemp
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastMintemp", &temp);
    jsonParseValueUint(&temp, data->forecastMintemp);
    // find forecastMaxrh
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastMaxrh", &temp);
    jsonParseValueUint(&temp, data->forecastMaxrh);
    // find forecastMinrh
    findKeyAndLoadVal(json->str, tokens, tokenSize, "forecastMinrh", &temp);
    jsonParseValueUint(&temp, data->forecastMinrh);
    // find PSR
    findKeyAndLoadVal(json->str, tokens, tokenSize, "PSR", &(data->PSR));

    return 0;
}

void loadStrFromToken(myStr_t *str, char *json, jsmntok_t *token)
{
    str->str = json + token->start;
    str->len = token->end - token->start;
}

void findKeyAndLoadVal(char *json, jsmntok_t *tokens, int tokenSize, char *key, myStr_t *val)
{
    int i;
    for (i = 0; i < tokenSize; i++)
    {
        if (jsoneq(json, &tokens[i], key) == 0)
        {
            loadStrFromToken(val, json, &tokens[i + 1]);
            return;
        }
    }
    val->str = NULL;
    val->len = 0;
}

int jsonParseCurrentWeatherData(myStr_t *json, weatherData_t *data)
{
    int i;
    int r;
    jsmn_parser p;
    jsmntok_t t[1024]; /* We expect no more than 1024 tokens */

    jsmn_init(&p);
    r = jsmn_parse(&p, json->str, json->len, t,
                   sizeof(t) / sizeof(t[0]));
    if (r < 0)
    {
        return -1;
    }

    /* Assume the top-level element is an object */
    if (r < 1 || t[0].type != JSMN_OBJECT)
    {
        return -2;
    }
    // find rainfall
    char *val;
    int length = jsonGetVal(json->str, t, r, "rainfall", &val);

    int r2;
    jsmn_parser p2;
    jsmntok_t t2[512]; /* We expect no more than 512 tokens */
    jsmn_init(&p2);

    r2 = jsmn_parse(&p2, val, length, t2,
                    sizeof(t2) / sizeof(t2[0]));
    if (r2 < 0)
    {
        return -3;
    }
    length = jsonGetVal(val, t2, r2, "data", &val);
    jsmn_init(&p2);
    r2 = jsmn_parse(&p2, val, length, t2,
                    sizeof(t2) / sizeof(t2[0]));
    if (r2 < 0)
    {
        return -4;
    }
    // sprint val
    int currentRainfallData = 0;
    for (i = 0; i < r2; i++)
    {
        if (t2[i].type == JSMN_OBJECT)
        {
            myStr_t rainfallDataStr;
            loadStrFromToken(&rainfallDataStr, val, &t2[i]);
            if (jsonParseRainfallData(&rainfallDataStr, &data->rainfallData[currentRainfallData]) == 0)
            {
                currentRainfallData++;
            }
        }
    }
    data->rainfallDataSize = currentRainfallData;

    // find temperature
    length = jsonGetVal(json->str, t, r, "temperature", &val);

    jsmn_init(&p2);
    r2 = jsmn_parse(&p2, val, length, t2,
                    sizeof(t2) / sizeof(t2[0]));
    if (r2 < 0)
    {
        return -5;
    }
    length = jsonGetVal(val, t2, r2, "data", &val);
    jsmn_init(&p2);
    r2 = jsmn_parse(&p2, val, length, t2,
                    sizeof(t2) / sizeof(t2[0]));
    if (r2 < 0)
    {
        return -6;
    }

    int currentTemperatureData = 0;
    for (i = 0; i < r2; i++)
    {
        if (t2[i].type == JSMN_OBJECT)
        {
            myStr_t temperatureDataStr;
            loadStrFromToken(&temperatureDataStr, val, &t2[i]);
            if (jsonParseTemperatureData(&temperatureDataStr, &data->temperatureData[currentTemperatureData]) == 0)
            {
                currentTemperatureData++;
            }
        }
    }
    data->temperatureDataSize = currentTemperatureData;

    // load time updated
    findKeyAndLoadVal(json->str, t, r, "updateTime", &data->updateTime);
}

int jsonParseForecastData(myStr_t *json, forecastData_t * const data)
{
    int i;
    int r;
    jsmn_parser p;
    jsmntok_t t[2048]; /* We expect no more than 1024 tokens */

    jsmn_init(&p);
    r = jsmn_parse(&p, json->str, json->len, t,
                   sizeof(t) / sizeof(t[0]));
    if (r < 0)
    {
        return -1;
    }

    /* Assume the top-level element is an object */
    if (r < 1)
    {
        return -2;
    }
    if (t[0].type != JSMN_OBJECT)
    {
        return -3;
    }
    // find generalSituation
    findKeyAndLoadVal(json->str, t, r, "generalSituation", &data->generalSituation);
    // find weatherForecast
    myStr_t weatherForecastStr;
    findKeyAndLoadVal(json->str, t, r, "weatherForecast", &weatherForecastStr);
    int r2;
    jsmn_parser p2;
    jsmntok_t t2[512]; /* We expect no more than 512 tokens */
    jsmn_init(&p2);

    r2 = jsmn_parse(&p2, weatherForecastStr.str, weatherForecastStr.len, t2,
                    sizeof(t2) / sizeof(t2[0]));
    if (r2 < 0)
    {
        return -3;
    }

    int currentWeatherForecast = 0;
    int jsmnObjectCount = 0;
    for (i = 0; i < r2; i++)
    {
        if (t2[i].type == JSMN_OBJECT)
        {
            jsmnObjectCount++;
            if (jsmnObjectCount % 5 == 1)
            {
                myStr_t weatherForecastDataStr;
                loadStrFromToken(&weatherForecastDataStr, weatherForecastStr.str, &t2[i]);
                if (jsonParseForecast(&weatherForecastDataStr, &data->weatherForecast[currentWeatherForecast]) == 0)
                {
                    currentWeatherForecast++;
                }
            }
        }
    }
    data->weatherForecastSize = currentWeatherForecast;

    // load date updated
    findKeyAndLoadVal(json->str, t, r, "updateTime", &data->updateTime);
    return 0;
}
