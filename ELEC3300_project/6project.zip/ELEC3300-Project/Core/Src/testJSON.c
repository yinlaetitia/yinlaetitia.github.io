#include "testJSON.h"
#include "jsonUtils.h"
// #include "jsmn.h"
// #include "cjson/cJSON.h"
// #define TEST_ON_PC
const char *testStr = "{\"rainfall\":{\"data\":[{\"unit\":\"mm\",\"place\":\"Central & Western District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Eastern District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Kwai Tsing\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Islands District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"North District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Sai Kung\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Sha Tin\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Southern District\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Tai Po\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Tsuen Wan\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Tuen Mun\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Wan Chai\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Yuen Long\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Yau Tsim Mong\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Sham Shui Po\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Kowloon City\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Wong Tai Sin\",\"max\":0,\"main\":\"FALSE\"},{\"unit\":\"mm\",\"place\":\"Kwun Tong\",\"max\":0,\"main\":\"FALSE\"}],\"startTime\":\"2023-05-07T08:45:00+08:00\",\"endTime\":\"2023-05-07T09:45:00+08:00\"},\"icon\":[62],\"iconUpdateTime\":\"2023-05-07T08:10:00+08:00\",\"uvindex\":{\"data\":[{\"place\":\"King\'s Park\",\"value\":1,\"desc\":\"low\"}],\"recordDesc\":\"During the past hour\"},\"updateTime\":\"2023-05-07T10:02:00+08:00\",\"temperature\":{\"data\":[{\"place\":\"King\'s Park\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Hong Kong Observatory\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Wong Chuk Hang\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Ta Kwu Ling\",\"value\":31,\"unit\":\"C\"},{\"place\":\"Lau Fau Shan\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Tai Po\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Sha Tin\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Tuen Mun\",\"value\":28,\"unit\":\"C\"},{\"place\":\"Tseung Kwan O\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Sai Kung\",\"value\":28,\"unit\":\"C\"},{\"place\":\"Cheung Chau\",\"value\":31,\"unit\":\"C\"},{\"place\":\"Chek Lap Kok\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Shek Kong\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Tsuen Wan Ho Koon\",\"value\":27,\"unit\":\"C\"},{\"place\":\"Tsuen Wan Shing Mun Valley\",\"value\":27,\"unit\":\"C\"},{\"place\":\"Hong Kong Park\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Shau Kei Wan\",\"value\":28,\"unit\":\"C\"},{\"place\":\"Kowloon City\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Happy Valley\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Wong Tai Sin\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Stanley\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Kwun Tong\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Sham Shui Po\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Kai Tak Runway Park\",\"value\":29,\"unit\":\"C\"},{\"place\":\"Yuen Long Park\",\"value\":30,\"unit\":\"C\"},{\"place\":\"Tai Mei Tuk\",\"value\":28,\"unit\":\"C\"}],\"recordTime\":\"2023-05-07T10:00:00+08:00\"},\"warningMessage\":\"\",\"mintempFrom00To09\":\"\",\"rainfallFrom00To12\":\"\",\"rainfallLastMonth\":\"\",\"rainfallJanuaryToLastMonth\":\"\",\"tcmessage\":\"\",\"humidity\":{\"recordTime\":\"2023-05-07T10:00:00+08:00\",\"data\":[{\"unit\":\"percent\",\"value\":81,\"place\":\"Hong Kong Observatory\"}]}}";
static char volatile jsonDebug[1024];
static int volatile jsonDebugCnt = 0;
void debugPrint(const char *str)
{

#ifdef TEST_ON_PC
    printf("%s", str);
#endif
}


void testJSON(void)
{
    int i;
    int r;
    jsmn_parser p;
    jsmntok_t t[1024]; /* We expect no more than 128 tokens */

    jsmn_init(&p);
    r = jsmn_parse(&p, testStr, strlen(testStr), t,
                    sizeof(t) / sizeof(t[0]));
    if (r < 0) {
        sprintf(jsonDebug, "Failed to parse JSON: %d\n", r);
        return;
    }

    /* Assume the top-level element is an object */
    if (r < 1 || t[0].type != JSMN_OBJECT) {
        sprintf(jsonDebug, "Object expected got type: %d\n", t[0].type);
        return;
    }
    debugPrint("JSON parsing success\n");
    char *val;
    int length = jsonGetVal(testStr, t, r, "rainfall", &val);

    int r2;
    jsmn_parser p2;
    jsmntok_t t2[512]; /* We expect no more than 128 tokens */
    jsmn_init(&p2);
    sprintf(jsonDebug, "last 100 chars: %.*s\n", 100, val + length - 100);
    debugPrint(jsonDebug);

    r2 = jsmn_parse(&p2, val, length, t2,
                    sizeof(t2) / sizeof(t2[0]));
    if (r2 < 0) {
        return;
    }
    sprintf(jsonDebug, "r2: %d\n", r2);
    debugPrint(jsonDebug);
    length = jsonGetVal(val, t2, r2, "data", &val);
    sprintf(jsonDebug, "first 100 chars: %.*s\n", 100, val);
    debugPrint(jsonDebug);
    jsmn_init(&p2);
    r2 = jsmn_parse(&p2, val, length, t2,
                    sizeof(t2) / sizeof(t2[0]));
    //sprint val
    rainfallData_t rainfallData[18];
    int currentRainfallData = 0;
    for (i = 0; i < r2; i++) {
        if (t2[i].type == JSMN_OBJECT) {
            jsonDebugCnt++;
            myStr_t rainfallDataStr;
            loadStrFromToken(&rainfallDataStr, val, &t2[i]);
            if (jsonParseRainfallData(&rainfallDataStr, &rainfallData[currentRainfallData]) == 0) {
                currentRainfallData++;
            }
        }
    }
    sprintf(jsonDebug, "Rainfall data: %.*s %d\n", rainfallData[0].place.len, rainfallData[0].place.str, currentRainfallData);
    debugPrint(jsonDebug);
}