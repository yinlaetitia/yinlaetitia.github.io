#include "fiveButtom.h"

unsigned int fiveButtomRead(void)
{
    unsigned int buttom = 0;
    if(HAL_GPIO_ReadPin(UP_GPIO_Port, UP_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x01;
    }
    if(HAL_GPIO_ReadPin(DOWN_GPIO_Port, DOWN_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x02;
    }
    if(HAL_GPIO_ReadPin(LEFT_GPIO_Port, LEFT_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x04;
    }
    if(HAL_GPIO_ReadPin(RIGHT_GPIO_Port, RIGHT_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x08;
    }
    if(HAL_GPIO_ReadPin(ENTER_GPIO_Port, ENTER_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x10;
    }
    if(HAL_GPIO_ReadPin(SET_GPIO_Port, SET_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x20;
    }
    if(HAL_GPIO_ReadPin(RESET_GPIO_Port, RESET_Pin) == GPIO_PIN_SET)
    {
        buttom |= 0x40;
    }

    return buttom;
}