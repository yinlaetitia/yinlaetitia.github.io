#include "state.h"
#include "fiveButtom.h"
#include "update.h"
#include "lcd.h"
#include "temperature.h"
#include "infraredSensor.h"
#include "weather.h"
#include "sht20.h"

int keyCooldown[] = {0, 0, 0, 0, 0, 0, 0};

enum key keyMap[] = {UP, DOWN, LEFT, RIGHT, ENTER, SET_K, RESET_K, IDLE};
static enum key volatile key = IDLE;
int currentSelection = 0;
char selections[MAX_SELECTIONS][MAX_SELECTION_NAME];
char title[MAX_SELECTION_NAME];
int selectionCount = 0;
int selectionPage = 0;
// state for idle, displaying temperature, and some other info
void idleEnter(void)
{
    clearScreen();
};

void idleExit(void){};
static unsigned int volatile lit = 0;

float temputure = 0; // calculated in average of TEMP samples
int tempCount = 0;

static float volatile debugTemp = 0;

int acOn = 0;

void tempUpdate(void)
{
    if (tempCount < TEMP_SAMPLE_NUM)
    {
        temputure *= tempCount;
        temputure += getTemperature();
        temputure /= ++tempCount;
    }
    else
    {
        temputure *= TEMP_SAMPLE_NUM - 1;
        temputure += getTemperature();
        temputure /= TEMP_SAMPLE_NUM;
    }
    debugTemp = temputure;
}
void setRainAreasSelections(void);
int idleUpdate(void)
{
    lit = HAL_GetTick();
    drawStringAtRow(0, 0, "Hello World!");
    // draw tick number
    char tick[32];
    sprintf(tick, "Tick: %d", lit);
    drawStringAtRow(0, 1, tick);

    if (acOn)
    {
        drawStringAtRow(0, 2, "AC should be on");
    }
    else
    {
        drawStringAtRow(0, 2, "AC should be off");
    }
    // draw key read
    keyRead();
    // char keys[32];
    // sprintf(keys, "Key: %d", key);
    // drawStringAtRow(0, 2, keys);
    // draw human motion if hasHuman draw human motion detected else draw no human motion detected
    char human[32];
    if (hasHuman())
    {
        sprintf(human, "Human Motion Detected");
    }
    else
    {
        sprintf(human, "No Human Motion Detected");
    }
    drawStringAtRow(0, 4, human);
    // if (rainAreasSize == 0)
    //     setRainAreasSelections();
    drawWeatherAtRow(5);

    // draw temperature
    char temp[40];
    char buf[20];
    // SHT20_GetValue();
    // gcvt(temputure, 4, buf);
    sprintf(temp, "Temputure: %d.%d", (int)(sht20_info.tempreture), (int)((sht20_info.tempreture - (int)(sht20_info.tempreture)) * 100));
    // sprintf(temp, "Temputure: %.2f", sht20_info.tempreture );

    drawStringAtRow(0, 3, temp);
    if (key == RIGHT)
    {
        return 6;
    }

    if (key != IDLE)
    {
        // return 0;
        return 1;
    }
    return 0;
};

struct state idleState = {
    0,
    "Ideal",
    idleEnter,
    idleExit,
    idleUpdate};

// setting selections and corresponding states

const char settingSelections[MAX_SELECTIONS][MAX_SELECTION_NAME] = {
    "Temperature Setting",
    "Light Control",
    "Rainfall Area Setting",
    "Temperature Area Setting",
    "Back"};
const int settingSelectionCount = 5;
// state map for setting selection
const int settingStateMap[MAX_SELECTIONS] = {2, 3, 4, 5, 0};

void settingEnter(void)
{
    clearScreen();
    // add some selections for debug
    selectionCount = 0;
    strcpy(title, "Setting");
    for (int i = 0; i < settingSelectionCount; i++)
    {
        strcpy(selections[selectionCount], settingSelections[i]);
        selectionCount++;
    }
    selectionInit();
};

void settingExit(void){};

int settingUpdate(void)
{
    int targetStateId = selectionUpdate();
    if (targetStateId != INT_NULL)
    {
        return settingStateMap[targetStateId];
    }
    return 1;
};
// state for setting
struct state settingState = {
    1,
    "Setting",
    settingEnter,
    settingExit,
    settingUpdate};

struct state *currentState = &idleState;

int settedTemp = 0;

void tempSetEnter(void)
{
    clearScreen();
    // select int value
    selectedInt = settedTemp;
    selectedIntMin = TEMP_SET_MIN;
    selectedIntMax = TEMP_SET_MAX;
    intSelectInit();
};

void tempSetExit(void){};

int tempSetUpdate(void)
{
    int targetStateId = intSelectUpdate();
    if (targetStateId != INT_NULL)
    {
        settedTemp = targetStateId;
        return 1;
    }
    return currentState->id;
};

struct state tempSetState = {
    2,
    "Tempture Setting",
    tempSetEnter,
    tempSetExit,
    tempSetUpdate};

unsigned char lights[LIGHT_NUM] = {0, 0, 0, 0};

void setLightsSelections(void)
{
    selectionCount = 0;
    strcpy(title, "Light Control");
    for (int i = 0; i < LIGHT_NUM; i++)
    {
        char lightName[32];
        if (lights[i])
        {
            sprintf(lightName, "Light %d: ON", i);
        }
        else
        {
            sprintf(lightName, "Light %d: OFF", i);
        }
        strcpy(selections[selectionCount++], lightName);
    }
    strcpy(selections[selectionCount++], "Back");
}

void updateLights(int index)
{
    if (index == LIGHT_NUM)
    {
        return;
    }
    lights[index] = !lights[index];
    setLightsSelections();
}

void lightControlEnter(void)
{
    clearScreen();
    setLightsSelections();
    selectionInit();
};

void lightControlExit(void){};

int lightControlUpdate(void)
{
    int targetStateId = selectionUpdate();
    if (targetStateId == LIGHT_NUM)
    { // return to setting state
        return 1;
    }
    if (targetStateId != INT_NULL)
    {
        updateLights(targetStateId);
        refreshSelectionAtRow(targetStateId);
    }
    return currentState->id;
};

struct state lightControlState = {
    3,
    "Light Control",
    lightControlEnter,
    lightControlExit,
    lightControlUpdate};

char rainAreas[MAX_AREA_NUM][MAX_AREA_NAME_LEN];
int rainAreasSize = 0;
int currentRainArea = 0;

void loadStrFromMyStr(char *dest, myStr_t *src)
{
    for (int i = 0; i < src->len; i++)
    {
        dest[i] = src->str[i];
    }
    dest[src->len] = '\0';
}

char tempAreas[MAX_AREA_NUM][MAX_AREA_NAME_LEN];
int tempAreasSize = 0;
int currentTempArea = 0;

void drawWeatherAtRow(int row)
{
    char buffer[128];
    if (rainAreasSize == 0)
    {
        sprintf(buffer, "No Rainfall Area or data");
        drawStringAtRow(0, row, buffer);
        return;
    }
    weatherData_t *weatherData = getWeatherData();
    char unit[128];
    char main[128];
    char buffer2[128];
    loadStrFromMyStr(unit, &weatherData->rainfallData[currentRainArea].unit);
    loadStrFromMyStr(main, &weatherData->rainfallData[currentRainArea].main);

    if (strcmp(main, "False"))
    { // draw area name
        loadStrFromMyStr(buffer2, &weatherData->rainfallData[currentRainArea].place);
        sprintf(buffer, "Rainfall data in %s:", buffer2);
        drawStringAtRow(0, row, buffer);
        // draw rainfall
        loadStrFromMyStr(buffer2, &weatherData->rainfallData[currentRainArea].max);
        sprintf(buffer, "Rainfall max: %s %s", buffer2, unit);
        drawStringAtRow(0, row + 2, buffer);
        // draw rainfall min
        loadStrFromMyStr(buffer2, &weatherData->rainfallData[currentRainArea].min);
        if (strlen(buffer2) != 0)
        {
            sprintf(buffer, "Rainfall min: %s %s", buffer2, unit);
            drawStringAtRow(0, row + 3, buffer);
        }
        else
        {
            sprintf(buffer, "Rainfall min: N/A");
            drawStringAtRow(0, row + 3, buffer);
        }
    }
    else
    {
        sprintf(buffer, " %.*s is under maintance", weatherData->rainfallData[currentRainArea].place.len, weatherData->rainfallData[currentRainArea].place.str);
        drawStringAtRow(0, row, buffer);
    }
    char value[32];
    loadStrFromMyStr(unit, &weatherData->temperatureData[currentTempArea].unit);
    loadStrFromMyStr(value, &weatherData->temperatureData[currentTempArea].value);
    loadStrFromMyStr(buffer2, &weatherData->temperatureData[currentTempArea].place);
    sprintf(buffer, "Temperature in %s is %s %s", buffer2, value, unit);
    drawStringAtRow(0, row + 5, buffer);
    loadStrFromMyStr(buffer2, &weatherData->updateTime);
    sprintf(buffer, "Last update: %s", buffer2);
    drawStringAtRow(0, row + 7, buffer);
}

void mystrcpy(char *dest, char *src, int len)
{
    for (int i = 0; i < len; i++)
    {
        dest[i] = src[i];
    }
    dest[len] = '\0';
}

void setRainAreasSelections(void)
{
    strcpy(title, "Rain Area Selection");
    selectionCount = 0;
    for (int i = 0; i < rainAreasSize; i++)
    {
        strcpy(selections[i], rainAreas[i]);
        selectionCount++;
    }
    strcpy(selections[selectionCount++], "Back");
}
void rainAreaSelectEnter(void)
{
    if (getWeatherData()->rainfallDataSize == 0)
    {
        return;
    }
    clearScreen();
    setRainAreasSelections();
    selectionInit();
}

int rainAreaSelectUpdate(void)
{
    if (getWeatherData()->rainfallDataSize == 0)
    {
        return 1;
    }
    int selection = selectionUpdate();
    if (selection != INT_NULL)
    {
        if (selection == rainAreasSize)
        {
            return 1;
        }
        currentRainArea = selection;
        return 1;
    }
    return currentState->id;
}

void rainAreaSelectExit(void)
{
}

struct state rainAreaState = {
    4,
    "Rain Area Selection",
    rainAreaSelectEnter,
    rainAreaSelectExit,
    rainAreaSelectUpdate};

void setTempAreasSelections(void)
{
    for (int i = 0; i < getWeatherData()->temperatureDataSize; i++)
    {
        mystrcpy(tempAreas[i], getWeatherData()->temperatureData[i].place.str, getWeatherData()->temperatureData[i].place.len);
    }
    tempAreasSize = getWeatherData()->temperatureDataSize;
    strcpy(title, "Temp Area Selection");
    selectionCount = 0;
    for (int i = 0; i < tempAreasSize; i++)
    {
        strcpy(selections[i], tempAreas[i]);
        selectionCount++;
    }
    strcpy(selections[selectionCount++], "Back");
}

void tempAreaSelectEnter(void)
{
    if (getWeatherData()->temperatureDataSize == 0)
    {
        return;
    }
    clearScreen();
    setTempAreasSelections();
    selectionInit();
}

int tempAreaSelectUpdate(void)
{
    if (getWeatherData()->temperatureDataSize == 0)
    {
        return 1;
    }
    int selection = selectionUpdate();
    if (selection != INT_NULL)
    {
        if (selection == tempAreasSize)
        {
            return 1;
        }
        currentTempArea = selection;
        return 1;
    }
    return currentState->id;
}

void tempAreaSelectExit(void)
{
}

struct state tempAreaState = {
    5,
    "Temp Area Selection",
    tempAreaSelectEnter,
    tempAreaSelectExit,
    tempAreaSelectUpdate};

int currentForecast = 0;

void getValueStr(valueUint_t *v, char *str)
{
    char buffer[10];
    char buffer2[10];
    loadStrFromMyStr(buffer, &v->value);
    loadStrFromMyStr(buffer2, &v->unit);
    sprintf(str, "%s %s", buffer, buffer2);
}

int drawForecastAtRow(int row)
{
    if (getForecastData()->weatherForecastSize == 0 || currentForecast >= getForecastData()->weatherForecastSize)
    {
        return -1;
    }
    drawStringAtRow(0, row, "Weather Forecast");
    char buffer[256];
    char buffer2[256];
    char buffer3[256];
    loadStrFromMyStr(buffer2, &getForecastData()->weatherForecast[currentForecast].forecastDate);
    loadStrFromMyStr(buffer3, &getForecastData()->weatherForecast[currentForecast].week);
    sprintf(buffer, "Date: %s %s", buffer2, buffer3);
    drawStringAtRow(0, row + 1, buffer);

    loadStrFromMyStr(buffer2, &getForecastData()->weatherForecast[currentForecast].forecastWind);
    sprintf(buffer, "Wind: %s", buffer2);
    drawStringAtRow(0, row + 2, buffer);

    loadStrFromMyStr(buffer2, &getForecastData()->weatherForecast[currentForecast].forecastWeather);
    sprintf(buffer, "Weather: %s", buffer2);
    drawStringAtRow(0, row + 6, buffer);

    getValueStr(getForecastData()->weatherForecast[currentForecast].forecastMaxtemp, buffer2);
    getValueStr(getForecastData()->weatherForecast[currentForecast].forecastMintemp, buffer3);
    sprintf(buffer, "Temperature: %s ~ %s", buffer3, buffer2);
    drawStringAtRow(0, row + 13, buffer);

    getValueStr(getForecastData()->weatherForecast[currentForecast].forecastMaxrh, buffer2);
    getValueStr(getForecastData()->weatherForecast[currentForecast].forecastMinrh, buffer3);
    sprintf(buffer, "Humidity: %s ~ %s", buffer3, buffer2);
    drawStringAtRow(0, row + 14, buffer);

    loadStrFromMyStr(buffer2, &getForecastData()->weatherForecast[currentForecast].PSR);
    sprintf(buffer, "Rain possibility: %s", buffer2);
    drawStringAtRow(0, row + 16, buffer);
}

void forecastEnter(void)
{
    if (getForecastData()->weatherForecastSize == 0)
    {
        return;
    }
    clearScreen();
    currentForecast = 0;
    drawForecastAtRow(0);
}

void forecastExit(void)
{
    clearScreen();
    LCD_Clear(0, 0, LCD_DispWindow_COLUMN, LCD_DispWindow_PAGE, WHITE);
}

int forecastUpdate(void)
{
    if (getForecastData()->weatherForecastSize == 0)
    {
        return 0;
    }
    keyRead();
    if (key != IDLE)
    {
        if (key == UP)
        {
            if (currentForecast > 0)
            {
                currentForecast--;
                LCD_Clear(0, 0, LCD_DispWindow_COLUMN, LCD_DispWindow_PAGE, WHITE);
                drawForecastAtRow(0);
            }
        }
        else if (key == DOWN)
        {
            if (currentForecast < getForecastData()->weatherForecastSize - 1)
            {
                currentForecast++;
                LCD_Clear(0, 0, LCD_DispWindow_COLUMN, LCD_DispWindow_PAGE, WHITE);
                drawForecastAtRow(0);
            }
        }
        else if (key == LEFT)
        {
            return 0;
        }
    }

    return currentState->id;
}

struct state forecastState = {
    6,
    "Weather Forecast",
    forecastEnter,
    forecastExit,
    forecastUpdate};

// state pointer array
struct state *states[] = {&idleState, &settingState, &tempSetState, &lightControlState, &rainAreaState, &tempAreaState, &forecastState};

unsigned int lastKeyUpdateTime = 0;

enum key keyRead(void)
{
    key = IDLE;
    unsigned int buttom = fiveButtomRead();
    for (int i = 0; i < 7; i++)
    {
        if (i == 4) // ENTER is broken
            continue;
        if (buttom & (0x01 << i))
        {
            if (keyCooldown[i] <= 0)
            {
                key = keyMap[i];
                keyCooldown[i] = KEY_COOLDOWN;
                lastKeyUpdateTime = HAL_GetTick();
                break;
            }
        }
    }
    // char keys[32];
    // sprintf(keys, "Key: %d", key);
    // drawStringAtRow(0, 10, keys);
    return key;
}

void stateInit(void)
{
    registerUpdateFunc(stateUpdate);
    registerUpdateFunc(tempUpdate);
    registerUpdateFunc(MotorControlUpdate);
    // registerUpdateFunc(SwitchControlUpdate);
}
static int volatile changeCnt = 0;
void changeState(int stateId)
{
    if (stateId < 0 || stateId >= sizeof(states) / sizeof(struct state *)) // invalid state id
    {
        return;
    }
    changeCnt++;
    currentState->exit();
    currentState = states[stateId];
    currentState->enter();
    // draw state name
    // LCD_DrawString(0, 50, currentState->name);
}

unsigned int lastUpdateTime = 0;
void stateUpdate(void)
{
    unsigned int currentTime = HAL_GetTick();

    int targetStateId = currentState->update();
    if (targetStateId != currentState->id)
    {
        changeState(targetStateId);
    }
    int dt = currentTime - lastUpdateTime;
    for (int i = 0; i < 7; i++)
    {
        if (i == 4) // ENTER is broken
            continue;
        if (keyCooldown[i] > 0)
        {
            keyCooldown[i] -= dt;
        }
    }
    if (HAL_GetTick() - lastKeyUpdateTime > IDLE_TIME && currentState->id != 0)
    {
        changeState(0);
    }
    lastUpdateTime = currentTime;
}

int occupiedSpace[MAX_ROW][2] = {-1};

void clearOccupiedRow(int row)
{
    if (occupiedSpace[row][0] != -1)
    {
        LCD_Clear(occupiedSpace[row][0], HEIGHT_EN_CHAR * row, occupiedSpace[row][1], HEIGHT_EN_CHAR, WHITE);
    }
    occupiedSpace[row][0] = -1;
    occupiedSpace[row][1] = -1;
}

void drawStringAtRow(int space, int row, char *str)
{
    clearOccupiedRow(row);
    LCD_DrawString(space, HEIGHT_EN_CHAR * row, str);
    occupiedSpace[row][0] = space;
    occupiedSpace[row][1] = strlen(str) * WIDTH_EN_CHAR;
    while (occupiedSpace[row][1] + space > LCD_DispWindow_COLUMN || row >= MAX_ROW)
    {
        occupiedSpace[++row][0] = 0;
        occupiedSpace[row][1] = occupiedSpace[row - 1][1] + occupiedSpace[row - 1][0] - LCD_DispWindow_COLUMN;
    }
}

void drawSelections()
{
    int page = currentSelection / MAX_SELECTION_ONE_PAGE;
    int start = page * MAX_SELECTION_ONE_PAGE;
    int end = start + MAX_SELECTION_ONE_PAGE;
    if (end > selectionCount)
    {
        end = selectionCount;
    }
    for (int i = start; i < end; i++)
    {
        if (i == currentSelection)
        {
            drawStringAtRow(10, (i % MAX_SELECTION_ONE_PAGE) + 1, selections[i]);
            continue;
        }
        drawStringAtRow(0, (i % MAX_SELECTION_ONE_PAGE) + 1, selections[i]);
    }
}

void drawSelectionUpdate(int oldSelection, int newSelection)
{
    int page = oldSelection / MAX_SELECTION_ONE_PAGE;
    int newPage = newSelection / MAX_SELECTION_ONE_PAGE;
    if (page != newPage)
    {
        clearScreen();
        drawStringAtRow(0, 0, title);
        drawSelections();
        return;
    }

    drawStringAtRow(0, oldSelection % MAX_SELECTION_ONE_PAGE + 1, selections[oldSelection]);
    drawStringAtRow(10, newSelection % MAX_SELECTION_ONE_PAGE + 1, selections[newSelection]);
}

void refreshSelectionAtRow(int selection)
{
    if (selection == currentSelection)
    {
        drawStringAtRow(10, selection % MAX_SELECTION_ONE_PAGE + 1, selections[selection]);
        return;
    }
    drawStringAtRow(0, selection + 1 % MAX_SELECTION_ONE_PAGE, selections[selection]);
}

void selectionInit(void)
{
    drawStringAtRow(0, 0, title);
    currentSelection = 0;
    selectionPage = 0;
    drawSelections();
}

int selectionUpdate(void)
{
    keyRead();
    int oldSelection = currentSelection;
    if (key == UP)
    {
        currentSelection--;
        if (currentSelection < 0)
        {
            currentSelection = selectionCount - 1;
        }
        drawSelectionUpdate(oldSelection, currentSelection);
    }
    if (key == DOWN)
    {
        currentSelection++;
        if (currentSelection >= selectionCount)
        {
            currentSelection = 0;
        }
        drawSelectionUpdate(oldSelection, currentSelection);
    }
    if (key == SET_K)
    {
        return currentSelection;
    }

    return INT_NULL;
}

void clearScreen(void)
{
    for (int i = 0; i < MAX_ROW; i++)
    {
        clearOccupiedRow(i);
    }
}

char intSelectTitle[MAX_SELECTION_NAME];

int selectedInt = 0;
int selectedIntMax = 0;
int selectedIntMin = 0;

void intSelectInit()
{
    drawStringAtRow(0, 0, intSelectTitle);
    // draw instruction
    drawStringAtRow(0, 1, "Press UP/DOWN to change by 10");
    drawStringAtRow(0, 2, "LEFT/RIGHT to change by 1");
    drawStringAtRow(0, 3, "Press SET to confirm");
    // draw current value
    char value[32];
    sprintf(value, "Value: %d", selectedInt);
    drawStringAtRow(0, 4, value);
}

void updateIntSelectValue(void)
{
    char value[32];
    sprintf(value, "Value: %d", selectedInt);
    drawStringAtRow(0, 4, value);
}

int intSelectUpdate()
{
    keyRead();
    int changed = 0;
    if (key == UP)
    {
        selectedInt += 10;
        if (selectedInt > selectedIntMax)
        {
            selectedInt = selectedIntMax;
        }
        changed = 1;
    }
    if (key == DOWN)
    {
        selectedInt -= 10;
        if (selectedInt < selectedIntMin)
        {
            selectedInt = selectedIntMin;
        }
        changed = 1;
    }
    if (key == LEFT)
    {
        selectedInt -= 1;
        if (selectedInt < selectedIntMin)
        {
            selectedInt = selectedIntMin;
        }
        changed = 1;
    }
    if (key == RIGHT)
    {
        selectedInt += 1;
        if (selectedInt > selectedIntMax)
        {
            selectedInt = selectedIntMax;
        }
        changed = 1;
    }
    if (key == SET_K)
    {
        return selectedInt;
    }

    if (changed)
    {
        updateIntSelectValue();
    }
    return INT_NULL;
}

void setTemperature(int temp)
{
    if (temp > TEMP_SET_MAX)
    {
        temp = TEMP_SET_MAX;
    }
    if (temp < TEMP_SET_MIN)
    {
        temp = TEMP_SET_MIN;
    }
    settedTemp = temp;
}

void parseBluetoothData(uint8_t *data)
{
    if (data[0] == 'T')
    { // 0x54
        // temperature
        int temp = data[1];
        setTemperature(temp);
        if (currentState->id == 2)
        {
            selectedInt = temp;
            updateIntSelectValue();
        }
    }
    if (data[0] == 'L')
    { // light control 0x4C
        int index = data[1];
        if (index < 0 || index >= LIGHT_NUM)
        {
            return;
        }
        int onOff = data[2] > 0 ? 1 : 0;
        lights[index] = onOff;
        if (currentState->id == 3)
        {
            setLightsSelections();
            refreshSelectionAtRow(index);
        }
    }
}

void weatherUpdateCallback()
{
    for (int i = 0; i < getWeatherData()->rainfallDataSize; i++)
    {
        mystrcpy(rainAreas[i], getWeatherData()->rainfallData[i].place.str, getWeatherData()->rainfallData[i].place.len);
    }
    rainAreasSize = getWeatherData()->rainfallDataSize;

    for (int i = 0; i < getWeatherData()->temperatureDataSize; i++)
    {
        mystrcpy(tempAreas[i], getWeatherData()->temperatureData[i].place.str, getWeatherData()->temperatureData[i].place.len);
    }
    tempAreasSize = getWeatherData()->temperatureDataSize;
}
extern UART_HandleTypeDef huart3;

static int uartCnt = 0;
void MotorControlUpdate()
{
    uint8_t data[2];
    if (hasHuman())
    {
        if (sht20_info.tempreture - settedTemp > TEMP_TOLERANCE)
        {
            // turn on ac
            data[0] = 0x01;
            data[1] = 0x01;
            HAL_UART_Transmit(&huart3, data, 2, 100);
            acOn = 1;
            uartCnt++;
        }
        else if (sht20_info.tempreture - settedTemp < -TEMP_TOLERANCE)
        {
            // turn off ac
            data[0] = 0x00;
            data[1] = 0x00;
            HAL_UART_Transmit(&huart3, data, 2, 100);
            acOn = 0;
            uartCnt++;
        }
    }
    else
    {
        // turn off ac
        // data[0] = 0xFF;
        data[0] = 0x00;
        data[0] = 0x00;
        HAL_UART_Transmit(&huart3, data, 2, 100);
        acOn = 0;
        uartCnt++;
    }
}

void SwitchControlUpdate()
{
    // uint8_t data[2];
    // if (hasHuman)
    // { // only light [0]
    //     data[0] = 0xFF;
    //     data[1] = 0x00;
    //     if (lights[0])
    //     {
    //         data[2] = 0x01;
    //     }
    //     else
    //     {
    //         data[2] = 0x00;
    //     }
    //     HAL_UART_Transmit(&huart1, data, 3, 100);
    // } else
    // {
    //     data[0] = 0xFF;
    //     data[1] = 0x00;
    //     data[2] = 0x00;
    //     HAL_UART_Transmit(&huart1, data, 3, 100);
    // }
}
