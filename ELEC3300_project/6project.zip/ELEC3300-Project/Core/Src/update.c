#include "update.h"

void (*updateFuncs[UPDATE_FUNC_NUM])(void) = {0}; // array of update functions

int updateFuncNum = 0; // number of update functions

void registerUpdateFunc(void (*func)(void)) {
    if (updateFuncNum < UPDATE_FUNC_NUM) {
        updateFuncs[updateFuncNum] = func;
        updateFuncNum++;
    } else {
        // TODO: error handling !!
    }
}

void update(void) {
    for (int i = 0; i < updateFuncNum; i++) {
        updateFuncs[i]();
    }
}