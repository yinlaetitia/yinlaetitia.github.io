#include "wifi.h"
#include "stm32f1xx_hal.h"

extern UART_HandleTypeDef huart4;

#define WIFI_UART &huart4

static int volatile wifiDebug = 0;
static int volatile wifiDebug2 = 0;

int sendCoolDown = 0;
int modeChanged = 0;
int init = 0;
void sendCmd(char *cmd)
{
    if (init == 0)
    {
        return;
    }
    if (sendCoolDown <= 0)
    {
        HAL_UART_Transmit(WIFI_UART, (uint8_t *)cmd, strlen(cmd), 2000);
        sendCoolDown = SEND_COOL_DOWN;
        modeChanged = 0;
    }
}

void wifiInit(void)
{
    char *cmd = "+++";
    HAL_UART_Transmit(WIFI_UART, (uint8_t *)cmd, strlen(cmd), 2000);
    sendCoolDown = 500;
    init = 1;
}

enum WifiState
{
    WIFI_IDLE,
    WIFI_CONNECTING,
    WIFI_CONNECTED,
    MODE_SET,
    TCP_CONNECTED,
    MSG_SENGING,
} wifiState = WIFI_CONNECTING;

static char volatile wifiBuffer[4096];

static char volatile wifiStrPiece[128];

int wifiBufferIndex = 0;
int wifiPieceIndex = 0;
int lastTick = 0;

enum QueryType queryType = NOQUERY;

void (*callback)(char *) = NULL;

int addQuery(enum QueryType type, void (*cb)(char *))
{
    if (queryType == NOQUERY)
    {
        queryType = type;
        callback = cb;
        return 0;
    }
    else
    {
        return -1;
    }
}

int sendChanger = 0;

void wifiUpdate(void)
{
    switch (wifiState)
    {
        {
        case WIFI_IDLE:
            break;

        case WIFI_CONNECTING:
            // if (sendChanger)
                sendCmd("AT+RST\r\n");
            // else
            //     sendCmd("AT+CWJAP=\"CP\",\"11111111\"\r\n");
            sendChanger = !sendChanger;
            break;

        case WIFI_CONNECTED:
            sendCmd("AT+CIPMODE=1\r\n");
            break;

        case MODE_SET:
            sendCmd("AT+CIPSTART=\"TCP\",\"laojk.club\",8000\r\n");
            break;

        case TCP_CONNECTED:
            sendCmd("AT+CIPSEND\r\n");
            break;

        case MSG_SENGING:
            if (queryType != NOQUERY)
            {
                char *msg = NULL;
                switch (queryType)
                {
                case WEATHER:
                    msg = "GET /weather/ HTTP/1.1\r\nHost: laojk.club\r\n\r\n";
                    break;
                case FORECAST:
                    msg = "GET /forecast/ HTTP/1.1\r\nHost: laojk.club\r\n\r\n";
                    break;
                }
                sendCmd(msg);
            }
            break;
        }
    }

    if (lastTick == 0)
    {
        lastTick = HAL_GetTick();
    }
    else
    {
        int tick = HAL_GetTick();
        int delta = tick - lastTick;
        lastTick = tick;
        sendCoolDown -= delta;
    }
}

void parseWifiData(char *data)
{
    wifiDebug += 1;
    if (wifiState != MSG_SENGING)
    {
        if (wifiBufferIndex == 0 && (*data == '\r' || *data == '\n' || *data == '\0' || *data == '+'))
        {
            return;
        }
        wifiBuffer[wifiBufferIndex++] = *data;
        if (wifiBuffer[wifiBufferIndex - 1] == '\n' || wifiBuffer[wifiBufferIndex - 1] == '\r')
        {
            wifiBuffer[wifiBufferIndex - 1] = '\0';
            if (modeChanged == 0)

            {
                parseLine(wifiBuffer);
            }

            memset(wifiBuffer, 0, wifiBufferIndex);
            wifiBufferIndex = 0;
        }
    }
    else
    {
        parseJson(data);
    }
}
int jsonLevel = 0;
void parseJson(char *json)
{
    if (jsonLevel == 0 && json[0] != '{')
    {
        return;
    }
    if (json[0] == '{')
    {
        jsonLevel += 1;
    }
    else if (json[0] == '}')
    {
        jsonLevel -= 1;
    }
    wifiBuffer[wifiBufferIndex++] = *json;
    if (jsonLevel == 0)
    {
        wifiBuffer[wifiBufferIndex] = '\0';

        callback(wifiBuffer);
        queryType = NOQUERY;

        memset(wifiBuffer, 0, wifiBufferIndex);
        wifiBufferIndex = 0;
    }
}

void parseLine(char *line)
{
    switch (wifiState)
    {
    case WIFI_CONNECTING:
        if (strstr(line, "CONNECTED") != NULL)
        {
            wifiState = WIFI_CONNECTED;
            modeChanged = 1;
        }
        break;
    case WIFI_CONNECTED:
        if (strstr(line, "OK") != NULL)
        {
            wifiState = MODE_SET;
            modeChanged = 1;
        }
        break;
    case MODE_SET:
        if (strstr(line, "CONNECT") != NULL)
        {
            wifiState = TCP_CONNECTED;
            modeChanged = 1;
        }
        break;
    case TCP_CONNECTED:
        if (strstr(line, "OK") != NULL)
        {
            wifiState = MSG_SENGING;
            modeChanged = 1;
        }
        break;
    }
}