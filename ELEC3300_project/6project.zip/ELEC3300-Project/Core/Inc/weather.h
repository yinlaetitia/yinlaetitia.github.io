#define WEATHER_UPDATE_INTERVAL 10000 // 100 seconds
#include "jsonUtils.h"

#define FORECAST_SIZE 9

void weatherInit(void);
void weatherUpdate(void);
weatherData_t *getWeatherData(void);
forecastData_t *getForecastData(void);