#include "stm32f1xx_hal.h"

extern ADC_HandleTypeDef hadc1;

float getTemperature();

int command(int upperbound, int lowerbound, int tollerance, float temperature);