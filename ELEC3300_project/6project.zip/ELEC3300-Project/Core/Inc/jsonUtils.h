#pragma once
typedef struct
{
  char *str;
  int len;
} myStr_t;

typedef struct
{
  myStr_t place;
  myStr_t unit;
  myStr_t max;  // may be null
  myStr_t min;  // may be null
  myStr_t main; // maintenace
} rainfallData_t;

typedef struct
{
  myStr_t place;
  myStr_t value;
  myStr_t unit;
} temperatureData_t;

typedef struct
{
  temperatureData_t *temperatureData;
  int temperatureDataSize;
  rainfallData_t *rainfallData;
  int rainfallDataSize;
  myStr_t updateTime;
} weatherData_t;

typedef volatile struct
{
  myStr_t value;
  myStr_t unit;
} valueUint_t;

typedef struct
{
  myStr_t forecastDate;
  myStr_t week;
  myStr_t forecastWind;
  myStr_t forecastWeather;
  valueUint_t* forecastMaxtemp;
  valueUint_t* forecastMintemp;
  valueUint_t* forecastMaxrh;
  valueUint_t* forecastMinrh;
  myStr_t PSR; // possibility of sudden rain
}forecast_t;

typedef struct
{
  myStr_t generalSituation;
  forecast_t *weatherForecast;
  int weatherForecastSize;
  myStr_t updateTime;
}forecastData_t;

#ifndef JSMN_TOKEN
#define JSMN_TOKEN

/**
 * JSON type identifier. Basic types are:
 * 	o Object
 * 	o Array
 * 	o String
 * 	o Other primitive: number, boolean (true/false) or null
 */
typedef enum
{
  JSMN_UNDEFINED = 0,
  JSMN_OBJECT = 1 << 0,
  JSMN_ARRAY = 1 << 1,
  JSMN_STRING = 1 << 2,
  JSMN_PRIMITIVE = 1 << 3
} jsmntype_t;

enum jsmnerr
{
  /* Not enough tokens were provided */
  JSMN_ERROR_NOMEM = -1,
  /* Invalid character inside JSON string */
  JSMN_ERROR_INVAL = -2,
  /* The string is not a full JSON packet, more bytes expected */
  JSMN_ERROR_PART = -3
};

/**
 * JSON token description.
 * type		type (object, array, string etc.)
 * start	start position in JSON data string
 * end		end position in JSON data string
 */
typedef struct jsmntok
{
  jsmntype_t type;
  int start;
  int end;
  int size;
#ifdef JSMN_PARENT_LINKS
  int parent;
#endif
} jsmntok_t;

/**
 * JSON parser. Contains an array of token blocks available. Also stores
 * the string being parsed now and current position in that string.
 */
typedef struct jsmn_parser
{
  unsigned int pos;     /* offset in the JSON string */
  unsigned int toknext; /* next token to allocate */
  int toksuper;         /* superior token node, e.g. parent object or array */
} jsmn_parser;

#endif /* JSMN_TOKEN */

int jsoneq(char *json, jsmntok_t *tok, char *s);
int jsonFindKey(char *json, jsmntok_t *tokens, int tokenSize, char *key);
int jsonGetVal(char *json, jsmntok_t *tokens, int tokenSize, char *key, char **val);
int jsonParseRainfallData(myStr_t *json, rainfallData_t *data);
int jsonParseTemperatureData(myStr_t *json, temperatureData_t *data);
int jsonParseValueUint(myStr_t *json, valueUint_t *data);
int jsonParseForecast(myStr_t *json, forecast_t * const data);

void loadStrFromToken(myStr_t *str, char *json, jsmntok_t *token);
void findKeyAndLoadVal(char *json, jsmntok_t *tokens, int tokenSize, char *key, myStr_t *val);
int jsonParseCurrentWeatherData(myStr_t *json, weatherData_t *data);
int jsonParseForecastData(myStr_t *json, forecastData_t * const data);
