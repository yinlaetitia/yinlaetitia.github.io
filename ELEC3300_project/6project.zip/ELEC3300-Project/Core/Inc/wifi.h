#define SEND_COOL_DOWN 3000

enum QueryType
{
    NOQUERY,
    WEATHER,
    FORECAST,
} queryType;

void wifiInit(void);

void wifiUpdate(void);

void parseWifiData(char *data);

void parseLine(char *line);

void parseJson(char *json);

int addQuery(enum QueryType type, void (*callback) (char *));