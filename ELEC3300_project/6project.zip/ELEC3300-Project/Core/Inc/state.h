#include "stdint.h"

#define MAX_SELECTIONS 32
#define MAX_SELECTION_NAME 32
#define MAX_SELECTION_ONE_PAGE 19

#define KEY_COOLDOWN 200

#define IDLE_TIME 5000

#define MAX_ROW 20

#define INT_NULL -1

#define LIGHT_NUM 4

#define TEMP_SAMPLE_NUM 10

#define TEMP_SET_MAX 50

#define TEMP_SET_MIN 0

#define MAX_AREA_NUM 30

#define MAX_AREA_NAME_LEN 32

#define TEMP_TOLERANCE 1

enum key {
    UP = 0,
    DOWN,
    LEFT,
    RIGHT,
    ENTER,
    SET_K,
    RESET_K,
    IDLE
};

enum key keyRead(void);

void stateInit(void);

void stateUpdate(void);

// struct for finite state machine
struct state {
    int id;
    char name[32];
    void (*enter)(void);
    void (*exit)(void);
    // return target state id
    int (*update)(void);
};

void selectionInit(void);

int selectionUpdate(void);

void parseBluetoothData(uint8_t *data);

void drawWeatherAtRow(int row);
void drawTempAtRow(int row);

void weatherUpdateCallback();

void MotorControlUpdate();
void SwitchControlUpdate();

int selectedInt;
int selectedIntMax;
int selectedIntMin;
int rainAreasSize;

