#include "stm32f103xe.h"
#include "stm32f1xx_hal.h"
#include "update.h"

#define HUMAN_LEAVE_TIME 5000

#define INFRARED_SENSOR_PORT GPIOC
#define INFRARED_SENSOR_PIN GPIO_PIN_8


void infraredSensorInit(void);

void infraredSensorUpdate(void);

int hasHuman(void);