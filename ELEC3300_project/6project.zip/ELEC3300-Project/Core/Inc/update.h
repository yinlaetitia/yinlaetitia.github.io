#pragma once
#define UPDATE_FUNC_NUM 20 // max number of update functions

// add update function to update function array
void registerUpdateFunc(void (*func)(void));

void update(void);