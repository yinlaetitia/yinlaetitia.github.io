#include "stm32f103xe.h"
#include "stm32f1xx_hal.h"


#define UP_GPIO_Port GPIOA
#define UP_Pin GPIO_PIN_4
#define DOWN_GPIO_Port GPIOA
#define DOWN_Pin GPIO_PIN_5
#define LEFT_GPIO_Port GPIOA
#define LEFT_Pin GPIO_PIN_6
#define RIGHT_GPIO_Port GPIOA
#define RIGHT_Pin GPIO_PIN_7
#define ENTER_GPIO_Port GPIOA
#define ENTER_Pin GPIO_PIN_3
#define SET_GPIO_Port GPIOA
#define SET_Pin GPIO_PIN_12
#define RESET_GPIO_Port GPIOB
#define RESET_Pin GPIO_PIN_1



unsigned int fiveButtomRead(void);


